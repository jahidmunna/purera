-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2018 at 06:54 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `puraradb`
--

-- --------------------------------------------------------

--
-- Table structure for table `customerdue`
--

CREATE TABLE `customerdue` (
  `dueID` int(11) NOT NULL,
  `cID` int(11) NOT NULL,
  `date` date NOT NULL,
  `dueJar` int(11) NOT NULL,
  `dueMoney` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customerdue`
--

INSERT INTO `customerdue` (`dueID`, `cID`, `date`, `dueJar`, `dueMoney`) VALUES
(1, 1, '2018-05-30', 0, 0),
(2, 1, '2018-05-31', 0, 0),
(3, 2, '2018-05-30', 5, 0),
(4, 2, '2018-05-31', 0, 0),
(5, 3, '2018-05-30', 0, 0),
(6, 5, '2018-05-30', 0, 0),
(7, 3, '2018-05-31', 0, 0),
(8, 5, '2018-05-31', 0, 0),
(9, 6, '2018-05-30', 0, 10),
(10, 6, '2018-05-31', 0, 0),
(11, 7, '2018-05-30', 0, 0),
(12, 8, '2018-05-30', 0, 10),
(13, 9, '2018-05-30', 1, 10),
(14, 10, '2018-05-30', 0, 0),
(15, 11, '2018-05-30', 10, 0),
(16, 7, '2018-05-31', 0, 0),
(17, 8, '2018-05-31', 0, 0),
(18, 9, '2018-05-31', 0, 0),
(19, 10, '2018-05-31', 0, 0),
(20, 11, '2018-05-31', 0, 0),
(21, 23, '2018-05-30', 0, 0),
(22, 65, '2018-05-30', 0, 0),
(23, 23, '2018-05-31', 0, 0),
(24, 65, '2018-05-31', 0, 0),
(25, 1, '2018-06-01', 0, 0),
(26, 2, '2018-06-01', 0, 0),
(27, 3, '2018-06-01', 0, 0),
(28, 6, '2018-06-01', 0, 0),
(29, 7, '2018-06-01', 0, 0),
(30, 8, '2018-06-01', 0, 0),
(31, 9, '2018-06-01', 0, 0),
(32, 10, '2018-06-01', 0, 0),
(33, 11, '2018-06-01', 0, 0),
(34, 23, '2018-06-01', 0, 0),
(35, 65, '2018-06-01', 0, 0),
(36, 5, '2018-06-01', 0, 0),
(37, 1, '2018-06-03', 0, 0),
(38, 2, '2018-06-03', 0, 0),
(39, 3, '2018-06-03', 0, 0),
(40, 6, '2018-06-03', 0, 0),
(41, 7, '2018-06-03', 0, 0),
(42, 8, '2018-06-03', 0, 0),
(43, 9, '2018-06-03', 1, 40),
(44, 10, '2018-06-03', 0, 0),
(45, 11, '2018-06-03', 0, 0),
(46, 23, '2018-06-03', 0, 0),
(47, 65, '2018-06-03', 0, 0),
(48, 5, '2018-06-03', 0, 0),
(49, 1, '2018-06-06', 5, 10),
(50, 2, '2018-06-06', 0, 0),
(51, 3, '2018-06-06', 0, 0),
(52, 6, '2018-06-06', 0, 0),
(53, 7, '2018-06-06', 0, 0),
(54, 8, '2018-06-06', 0, 0),
(55, 9, '2018-06-06', 1, 400),
(56, 10, '2018-06-06', 0, 0),
(57, 11, '2018-06-06', 0, 0),
(58, 23, '2018-06-06', 0, 0),
(59, 65, '2018-06-06', 0, 0),
(60, 5, '2018-06-07', 0, 0),
(61, 1, '2018-06-07', 5, 10),
(62, 2, '2018-06-07', 0, 0),
(63, 3, '2018-06-07', 0, 0),
(64, 6, '2018-06-07', 0, 0),
(65, 7, '2018-06-07', 0, 0),
(66, 8, '2018-06-07', 0, 0),
(67, 9, '2018-06-07', 1, 400),
(68, 10, '2018-06-07', 0, 0),
(69, 11, '2018-06-07', 0, 0),
(70, 23, '2018-06-07', 0, 0),
(71, 65, '2018-06-07', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `customertable`
--

CREATE TABLE `customertable` (
  `customerID` int(11) NOT NULL,
  `customerRate` int(11) NOT NULL,
  `customerName` varchar(50) NOT NULL,
  `customerCorrospondingStaff` int(11) NOT NULL,
  `customerPhone` varchar(15) DEFAULT NULL,
  `customerAddress` varchar(150) DEFAULT NULL,
  `customerEmail` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customertable`
--

INSERT INTO `customertable` (`customerID`, `customerRate`, `customerName`, `customerCorrospondingStaff`, `customerPhone`, `customerAddress`, `customerEmail`) VALUES
(1, 30, 'Rahim', 1, '', '', ''),
(2, 30, 'test2', 1, '', '', ''),
(3, 40, 'test3', 1, '', '', ''),
(5, 15, 'test4', 2, '', '', ''),
(6, 40, 'test5', 1, '', '', ''),
(7, 20, 'test7', 1, '', '', ''),
(8, 40, 'test8', 1, '', '', ''),
(9, 40, 'test9', 1, '', '', ''),
(10, 40, 'test10', 1, '', '', ''),
(11, 40, 'test11', 1, '', '', ''),
(23, 30, 'asfd', 1, '', '', ''),
(65, 40, 'a;sdflj', 1, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `delevery`
--

CREATE TABLE `delevery` (
  `deleveryID` int(11) NOT NULL,
  `cID` int(11) NOT NULL,
  `date` date NOT NULL,
  `jarGiven` int(11) NOT NULL DEFAULT '0',
  `jarReceive` int(11) NOT NULL DEFAULT '0',
  `paymentToday` int(11) NOT NULL DEFAULT '0',
  `commentIfAny` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delevery`
--

INSERT INTO `delevery` (`deleveryID`, `cID`, `date`, `jarGiven`, `jarReceive`, `paymentToday`, `commentIfAny`) VALUES
(1, 1, '2018-05-31', 5, 0, 50, ''),
(2, 2, '2018-05-31', 3, 0, 20, ''),
(3, 3, '2018-05-31', 1, 0, 0, ''),
(4, 5, '2018-05-31', 0, 0, 0, ''),
(5, 6, '2018-05-31', 0, 0, 0, ''),
(6, 7, '2018-05-31', 0, 0, 0, ''),
(7, 8, '2018-05-31', 0, 0, 0, ''),
(8, 9, '2018-05-31', 1, 1, 0, ''),
(9, 10, '2018-05-31', 0, 0, 0, ''),
(10, 11, '2018-05-31', 1, 0, 30, ''),
(11, 23, '2018-05-31', 0, 0, 0, ''),
(12, 65, '2018-05-31', 0, 0, 0, ''),
(13, 1, '2018-06-01', 0, 0, 0, ''),
(14, 2, '2018-06-01', 0, 0, 0, ''),
(15, 3, '2018-06-01', 0, 0, 0, ''),
(16, 6, '2018-06-01', 0, 0, 0, ''),
(17, 7, '2018-06-01', 0, 0, 0, ''),
(18, 8, '2018-06-01', 0, 0, 0, ''),
(19, 9, '2018-06-01', 0, 0, 0, ''),
(20, 10, '2018-06-01', 0, 0, 0, ''),
(21, 11, '2018-06-01', 0, 0, 0, ''),
(22, 23, '2018-06-01', 0, 0, 0, ''),
(23, 65, '2018-06-01', 0, 0, 0, ''),
(24, 5, '2018-06-01', 0, 0, 0, ''),
(25, 1, '2018-06-03', 0, 0, 0, ''),
(26, 2, '2018-06-03', 0, 0, 0, ''),
(27, 3, '2018-06-03', 0, 0, 0, ''),
(28, 6, '2018-06-03', 0, 0, 0, ''),
(29, 7, '2018-06-03', 0, 0, 0, ''),
(30, 8, '2018-06-03', 0, 0, 0, ''),
(31, 9, '2018-06-03', 1, 0, 0, ''),
(32, 10, '2018-06-03', 0, 0, 0, ''),
(33, 11, '2018-06-03', 0, 0, 0, ''),
(34, 23, '2018-06-03', 0, 0, 0, ''),
(35, 65, '2018-06-03', 0, 0, 0, ''),
(36, 5, '2018-06-03', 0, 0, 0, ''),
(37, 1, '2018-06-06', 0, 0, 0, ''),
(38, 2, '2018-06-06', 0, 0, 0, ''),
(39, 3, '2018-06-06', 0, 0, 0, ''),
(40, 6, '2018-06-06', 0, 0, 0, ''),
(41, 7, '2018-06-06', 0, 0, 0, ''),
(42, 8, '2018-06-06', 0, 0, 0, ''),
(43, 9, '2018-06-06', 0, 0, 0, ''),
(44, 10, '2018-06-06', 0, 0, 0, ''),
(45, 11, '2018-06-06', 0, 0, 0, ''),
(46, 23, '2018-06-06', 0, 0, 0, ''),
(47, 65, '2018-06-06', 0, 0, 0, ''),
(48, 5, '2018-06-07', 0, 0, 0, ''),
(49, 1, '2018-06-07', 10, 10, 300, ''),
(50, 2, '2018-06-07', 0, 0, 0, ''),
(51, 3, '2018-06-07', 0, 0, 0, ''),
(52, 6, '2018-06-07', 0, 0, 0, ''),
(53, 7, '2018-06-07', 0, 0, 0, ''),
(54, 8, '2018-06-07', 0, 0, 0, ''),
(55, 9, '2018-06-07', 0, 0, 0, ''),
(56, 10, '2018-06-07', 0, 0, 0, ''),
(57, 11, '2018-06-07', 0, 0, 0, ''),
(58, 23, '2018-06-07', 0, 0, 0, ''),
(59, 65, '2018-06-07', 0, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `managertable`
--

CREATE TABLE `managertable` (
  `managerID` int(11) NOT NULL,
  `managerName` varchar(50) DEFAULT NULL,
  `managerPassword` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `managertable`
--

INSERT INTO `managertable` (`managerID`, `managerName`, `managerPassword`) VALUES
(1, 'admin', '7841fb1f92b99194ca818d410cb09430731b6285');

-- --------------------------------------------------------

--
-- Table structure for table `stafftable`
--

CREATE TABLE `stafftable` (
  `staffID` int(11) NOT NULL,
  `staffName` varchar(50) NOT NULL,
  `staffPhone` varchar(15) NOT NULL,
  `staffAddress` varchar(150) DEFAULT NULL,
  `staffEmail` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stafftable`
--

INSERT INTO `stafftable` (`staffID`, `staffName`, `staffPhone`, `staffAddress`, `staffEmail`) VALUES
(1, 'karim', '01675000333', 'goopalgonj', 'karim@gmail.com'),
(2, 'Rahim', '017000111', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customerdue`
--
ALTER TABLE `customerdue`
  ADD PRIMARY KEY (`dueID`),
  ADD UNIQUE KEY `cID` (`cID`,`date`);

--
-- Indexes for table `customertable`
--
ALTER TABLE `customertable`
  ADD PRIMARY KEY (`customerID`),
  ADD UNIQUE KEY `customerName` (`customerName`,`customerPhone`),
  ADD KEY `customerCorrospondingStaff` (`customerCorrospondingStaff`);

--
-- Indexes for table `delevery`
--
ALTER TABLE `delevery`
  ADD PRIMARY KEY (`deleveryID`),
  ADD UNIQUE KEY `cID` (`cID`,`date`);

--
-- Indexes for table `managertable`
--
ALTER TABLE `managertable`
  ADD PRIMARY KEY (`managerID`);

--
-- Indexes for table `stafftable`
--
ALTER TABLE `stafftable`
  ADD PRIMARY KEY (`staffID`),
  ADD UNIQUE KEY `staffName` (`staffName`,`staffPhone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customerdue`
--
ALTER TABLE `customerdue`
  MODIFY `dueID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `delevery`
--
ALTER TABLE `delevery`
  MODIFY `deleveryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `managertable`
--
ALTER TABLE `managertable`
  MODIFY `managerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `stafftable`
--
ALTER TABLE `stafftable`
  MODIFY `staffID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customerdue`
--
ALTER TABLE `customerdue`
  ADD CONSTRAINT `customerdue_ibfk_1` FOREIGN KEY (`cID`) REFERENCES `customertable` (`customerID`);

--
-- Constraints for table `customertable`
--
ALTER TABLE `customertable`
  ADD CONSTRAINT `customertable_ibfk_1` FOREIGN KEY (`customerCorrospondingStaff`) REFERENCES `stafftable` (`staffID`);

--
-- Constraints for table `delevery`
--
ALTER TABLE `delevery`
  ADD CONSTRAINT `delevery_ibfk_1` FOREIGN KEY (`cID`) REFERENCES `customertable` (`customerID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
